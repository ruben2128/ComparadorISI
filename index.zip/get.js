var baseurl = "https://2v1s89q67i.execute-api.us-west-2.amazonaws.com/dev/ordenadores";
var aplication = document.querySelector(".grid");

fetch(baseurl)
.then(res => res.json())
.then(data => {
    data['ordenadores'].forEach(ordenador => {
        
        var prueba = `<div class="card" id=${ordenador.ordenadorId}>
        <div class="imgBox">
          <img src="descarga.jpg" alt="prueba" class="mouse">
        </div>
        <div class="contentBox">
          <h3>${ordenador.modelo}</h3>
          <h2 class="price">1 €</h2>
          <a href=./ordenador.html?id=${ordenador.ordenadorId} class="buy">Buy Now</a>
        </div>
      </div>`;
        



        aplication.innerHTML += prueba;


    });
    console.log(data)
})
.catch(err => console.log(err))


    
    